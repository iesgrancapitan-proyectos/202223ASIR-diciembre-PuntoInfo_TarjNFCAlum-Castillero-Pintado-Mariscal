<?php

require_once 'model/tarjeta.php';
require_once 'model/usuario.php';

class TarjetaController
{
    public $page_title;
    public $page_error;
    public $view;

    public function __construct()
    {
        $this->view = 'login_principal';
        $this->tarjetaObj = new Tarjeta();
        $this->usuarioObj = new Usuario();
    }

    /**
     * Formulario de insertar tarjeta
     */
    public function form()
    {
        if (isset($_SESSION['idTarjeta'])) {
            return $this->login();
        }
        $this->page_title = 'INSERTE TARJETA';
    }

    /**
     * Realizar login y redireccionar a la zona según idPerfil
     */
    public function login(): void
    {
        if ((!isset($_POST["idTarjeta"]) || !is_numeric($_POST["idTarjeta"])) && !isset($_SESSION['idTarjeta'])) {
            $this->view = 'login_principal';
            $this->page_title = 'INSERTE TARJETA';
            $this->page_error = 'Introduce un número correcto';
            return;
        }
        try {
            $user = $this->tarjetaObj->login($_POST);
        } catch (\Throwable $th) {
            $this->view = 'login_principal';
            $this->page_title = 'INSERTE TARJETA';
            $this->page_error = $th->getMessage();
            return;
        }
        if ($user === '') {
            $this->view = 'login_principal';
            $this->page_title = 'INSERTE TARJETA';
        } else {
            if ($this->usuarioObj->isAdmin($user['idUsuario'])) {
                $this->view = 'index_admin';
                $this->page_title = 'ADMINISTRACIÓN';
            } else {
                $this->getPerfilView($user['idPerfil']);
            }
        }
        $_GET["response"] = true;
    }

    public function logout()
    {
        session_unset();
        session_destroy();
        $this->view = 'login_principal';
        $this->page_title = 'INSERTE TARJETA';
    }

    /**
     * Función que determina la vista para redireccionar al usuario
     * 
     * @param int $idPerfil
     * 
     * @return void
     */
    private function getPerfilView(int $idPerfil): void
    {
        switch ($idPerfil) {
            case '1':
                // header("Location:index.php?page=indexAdmin");
                $this->view = 'index_admin';
                $this->page_title = 'ADMINISTRACIÓN';
                break;
            case '2':
                // header("Location:index.php?page=indexProfesor");
                $this->view = 'index_profesor';
                $this->page_title = 'ZONA PROFESOR';
                break;
            case '3':
                // header("Location:index.php?page=indexAlumno");
                $this->view = 'index_alumno';
                $this->page_title = 'ZONA ALUMNO';
                break;
            default:
                $this->view = 'login_principal';
                $this->page_title = 'INSERTE TARJETA';
                break;
        }
    }
}
