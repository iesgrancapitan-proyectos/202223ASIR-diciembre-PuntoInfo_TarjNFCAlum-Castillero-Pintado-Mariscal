<?php

require_once 'model/tarjeta.php';
require_once 'model/usuario.php';

class UsuarioController
{
    public $page_title;
    public $page_error;
    public $view;

    public function __construct()
    {
        if (!isset($_SESSION['user'])) {
            header('Location: index.php');
        }
        $this->view = 'user_list';
        $this->tarjetaObj = new Tarjeta();
        $this->usuarioObj = new Usuario();
    }

    /**
     * Listado de usuarios
     */
    public function listado()
    {
        $this->select = $_POST['select'] ?? null;
        $this->listado = [];

        if (null !== $this->select) {
            $type = explode('_', $this->select)[0];
            $value = explode('_', $this->select)[1];
            $this->listado = $this->usuarioObj->getFilterUser($type, $value);
        }

        $this->departamentos = $this->usuarioObj->getDepartamentos();
        $this->unidades = $this->usuarioObj->getUnidades();
        $this->page_title = 'LISTADO DE USUARIOS';
    }

    public function eliminar()
    {
        $this->usuarios = $_POST['usuarios'] ?? null;

        if (null !== $this->usuarios) {
            $this->listado = $this->usuarioObj->delete($this->usuarios);
            $this->listado = $this->usuarioObj->delete($this->usuarios);
        }
        
        $this->listado();
    }
}
