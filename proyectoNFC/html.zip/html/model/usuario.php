<?php

class Usuario
{

	private $conection;

	/* Set conection */
	public function getConection()
	{
		$dbObj = new conexiondb();
		$this->conection = $dbObj->initConex();
	}

	/* Save note */
	public function isAdmin(int $idUsuario): bool
	{
		$this->getConection();

		$query = $this->conection->query("SELECT * FROM administracion WHERE idUsuario=" . $idUsuario);

		return $query->num_rows === 1;
	}

	public function getFilterUser($type, $value)
	{
		$this->getConection();

		$query = $this->conection->query("SELECT * FROM usuarios WHERE " . $type . " = '" . $value . "'");
		$array = $query->fetch_all();

		return $array;
	}

	public function getDepartamentos()
	{
		$this->getConection();

		$query = $this->conection->query("SELECT DISTINCT departamento FROM usuarios WHERE departamento is NOT NULL");
		$array = $query->fetch_all();

		return $array;
	}

	public function getUnidades()
	{
		$this->getConection();

		$query = $this->conection->query("SELECT DISTINCT unidad FROM usuarios WHERE unidad is NOT NULL");
		$array = $query->fetch_all();

		return $array;
	}

	public function delete($users)
	{
		$this->getConection();

		foreach ($users as $user) {
			if ($user > 1) {
				$this->conection->query("DELETE FROM usuarios_tarjetas WHERE idUsuario=$user");
			}
		}
	}
}
