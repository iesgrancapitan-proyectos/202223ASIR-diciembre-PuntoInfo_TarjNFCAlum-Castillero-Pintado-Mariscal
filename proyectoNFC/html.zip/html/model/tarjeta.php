<?php

class Tarjeta
{

	private $conection;

	/* Set conection */
	public function getConection(): void
	{
		$dbObj = new conexiondb();
		$this->conection = $dbObj->initConex();
	}

	/* Get user */
	public function login($param)
	{
		$this->getConection();
		$idTarjeta = isset($param["idTarjeta"]) ? $param["idTarjeta"] : $_SESSION['idTarjeta'];

		$query = $this->conection->query("SELECT idUsuario FROM usuarios_tarjetas WHERE idTarjeta=" . $idTarjeta);
		if ($query->num_rows === 0) throw new Exception("No se ha encontrado esta tarjeta");

		$_SESSION['idTarjeta'] = $idTarjeta;

		$array = $query->fetch_assoc();

		if (count($array) > 0) {
			$query = $this->conection->query("SELECT idUsuario, email, idPerfil FROM usuarios WHERE idUsuario=" . $array["idUsuario"]);
			if ($query->num_rows === 0) throw new Exception("No se ha podido recuperar los datos del usuario asociado a la tarjeta");
			$user = $query->fetch_assoc();
			$_SESSION['user'] = $user;
		}

		return $user;
	}
}
