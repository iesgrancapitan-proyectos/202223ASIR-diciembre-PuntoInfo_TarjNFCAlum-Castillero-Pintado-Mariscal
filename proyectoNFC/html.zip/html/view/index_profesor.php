<header id='medio' class='masthead'>
    <div id='divcentral' class='container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center'>
        <div class='d-flex justify-content-center'>
            <div id='divcentral2' class='text-center'>
                <h2 id='letra2' class='mx-auto mt-2 mb-5 letradedia'>Elija una opción</h2>
                <h5 id='letra2' class='mx-auto mt-2 mb-5 letradedia'>El USUARIO te ha concedido permiso</h5>
                <a class='btn btn-primary' href='index.php?page=comienzoDeCurso'> ComienzoCurso</a>
                <a class='btn btn-primary' href='index.php?page=listadoUsurios'>Listado usuarios</a>
                <a class='btn btn-primary' href='index.php?page=listadoTarjetas'>Listado tarjetas</a>
                <a class='btn btn-primary' href='index.php?page=accesoBano'>Acceso al baño</a>
                <a class='btn btn-primary' href='index.php?controller=tarjeta&action=logout'>Cerrar la sesión</a>
            </div>
        </div>
    </div>
</header>