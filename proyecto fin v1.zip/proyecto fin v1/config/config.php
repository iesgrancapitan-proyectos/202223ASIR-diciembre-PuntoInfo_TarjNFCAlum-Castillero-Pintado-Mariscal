<?php

/* Database connection values */
/* define("DB_HOST", "localhost");
define("DB", "grancapitan");
define("DB_USER", "root");
define("DB_PASS", "test"); */

/* Default options */
define("DEFAULT_CONTROLLER", "tarjeta");
define("DEFAULT_ACTION", "form");
