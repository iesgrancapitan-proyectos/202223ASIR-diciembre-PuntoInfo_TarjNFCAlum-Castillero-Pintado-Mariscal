<div id=''>
    <form method="POST" action=index.php?page=pagConsulta>
        <div id=''>
            <div id=''>Selecciona Usuario/div>
                <div><input type='text' name='idUsuario'>$nombreUsuario</div>
            </div>
            <div>
                <input type='submit' class='btn btn-primary' value='Acceder' name='accederAdmin'>
                <a class='btn btn-primary' href='javascript:history.go(-1)'>Volver</a>
            </div>
        </div>
    </form>
    <div>atras</div>
</div>