<div class="text-center w-100">
    <p>Aseo libre</p>
</div>

<script>
    window.onload = function () {
        document.getElementsByTagName('body')[0].className = 'verde';
    };
</script>