<div id='divcentral' class='container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center'>
    <div class='d-flex justify-content-center'>
        <div id='divcentral2' class='text-center'>
            <a class='btn btn-primary' href='index.php?controller=tarjeta&action=getDepart'>Profesor</a>
            <a class='btn btn-primary' href='index.php?controller=tarjeta&action=getUnidad'>Alumno</a>
            <a class='btn btn-primary' href='javascript:history.go(-1)'>Volver</a>
        </div>
    </div>
</div>