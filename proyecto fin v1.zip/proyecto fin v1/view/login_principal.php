<div id='divcentral' class='container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center'>
    <form method="POST" action=index.php?controller=tarjeta&action=login>
        <div id='divcentral' class='container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center'>Tarjeta</div>
        <div class="mb-3">
            <input type='text' class="w-100" name='idTarjeta'>
        </div>
        <div>
            <input type='submit' class='btn btn-primary w-100' value='Acceder' name='acceder'>
        </div>
    </form>
</div>