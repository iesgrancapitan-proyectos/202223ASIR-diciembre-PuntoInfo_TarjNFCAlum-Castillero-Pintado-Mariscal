<div class="text-center w-100">
    <p>Aseo ocupado, intententelo mas tarde</p>
</div>

<script>
    window.onload = function () {
        document.getElementsByTagName('body')[0].className = 'rojo';
    };
</script>